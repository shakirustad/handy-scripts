# Python Rock-Paper-Scissor GAME

The Python script shows the easy to understand and executable program which is used to play the rock-paper-scissor game with scorecard and wish to start or exit.

## Requirement

Python 3.xx

## Running the script

```bash
python Rock-Paper-Scissor.py
```
