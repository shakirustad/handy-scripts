# What is AI bot>
A chatbot (also known as a talkbot, chatterbot, Bot, IM bot, interactive agent,
or Artificial Conversational Entity) is a computer program or an artificial 
intelligence which conducts a conversation via auditory or textual methods.

## How to use it >
Start by Running the below command on your unix terminal or windows CMD

```bash
$ python bash.py
```
