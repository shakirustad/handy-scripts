# Upload files & folders from your machine to Amazon S3

A python script that will upload your files & folder to Amzzon S3 using python and boto3

## Requirement

Python 2.xx
boto3
```bash
pip install boto3
```

#Usage 
Go to Upload_files_to_s3 directory and add your folder's name you want to upload to s3 and then run upload_files_to_s3.py as below:
```bash
$ python upload_files_to_s3.py
```
