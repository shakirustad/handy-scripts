from setuptools import setup

setup(name='Twitter_Tool',
      version='0.1',
      description='Web scraping ',
      url='http://github.com/sdf94/Twitter_Tool',
      author='Sarah Floris',
      author_email='sdf11c@acu.edu',
      license='MIT',
      packages=['Twitter_Tool'],
      zip_safe=False)