
--> Clone the project

--> run pip install -r requirements.txt

-- > python3 main.py

-- >It will launch a firefox tab showing the map


This project visualise the current COVID position of India on a map using Folium

(will extend it to more countries later)
