Here is this python3 code to get a notification/battery alert when the battery is low (35%)and while charging it is 98% it will give notification till you didn't plug-in when it is low(35%) and out when it is 98% for a Windows laptop.Install some Python library by writing some pip code in terminal.

```
pip install psutil

pip install pyttsx3

pip install win10toast
```
than run the file.
using ```python``` for windows and ```python3``` for linux and follow up ```Battery_notification.py```
