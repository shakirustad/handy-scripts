## Python script to watermark your images

in the `main.py` file edit the following items:

```bash
        "<input folder>",
        "<output folder>",
        "<watermark image>"
```

using the input folder path to loop over all images and output them to outputfolder.

Best practise is to use a image with transparent background.
