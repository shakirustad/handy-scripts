For linux/unix users :

./gmail_messenger.py
