# InstadpShower

This is a simple python script which uses web scraping techniques to display the instagram dp of any user just by typing its username.

To use this script, you need to have bs4 and requests libraries of python installed in your local machine.

To install bs4 and requests, use the following command

```
pip install beautifulsoup4
```
```
pip install requests
```

Once libraries are installed, just run the script and type the instagram username of the person, whom you want to see the dp of, and the instagram dp will be displayed on the browser.
