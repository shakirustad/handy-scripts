## CSV to Excel

This programme writes the data in any Comma-separated value file (such as: .csv or .data) to a Excel file.

## Requirements

Install the required libraries:

	$ pip install -r requirements.txt

After that run with:

	$ python main.py
