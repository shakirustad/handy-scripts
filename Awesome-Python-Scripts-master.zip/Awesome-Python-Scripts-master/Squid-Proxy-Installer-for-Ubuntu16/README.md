**Squid Proxy Automation-Script**
*it's for Ubuntu 14 or 16 servers.*
**You can browse with your installed squid proxy on your server**
You need simple server or OpenVPN  ovpn file.

Go python3 Squid_Proxy.py and install Squid Proxy

 1. Install Squid Proxy
 2. Add Password
 3. Change Password
 4. Remove Password
 5. Uninstall Squid Proxy
 6. Exit