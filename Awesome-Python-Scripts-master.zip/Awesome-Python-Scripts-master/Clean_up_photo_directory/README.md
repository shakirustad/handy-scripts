# Clean_up_photo


## Description

This program is used to find out the "bad" picture files and then eventually delete them.

## Usage

Run the clean_up_photo.py
