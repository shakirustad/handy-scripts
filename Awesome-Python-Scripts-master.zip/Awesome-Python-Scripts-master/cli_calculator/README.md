# calc_argparser
Calculadora via CLI

# Instructions
To run CLI_Calculator execute:

- `python args.py -h` - For help
- `python args.py --sum x y` - To sum two numbers
- `python args.py --sub x y` - To substraction two numbers
- `python args.py --mult x y` - To multiplication two numbers
- `python args.py --div x y` - To divide two numbers
