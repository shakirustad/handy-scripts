# PX-to-REM Script

This script can convert **PX to REM** and **REM to PX**

## Usage call python script then select your interest **PX to REM** or **REM to PX** to convert

``` bash
$ python px_to_rem.py
```
