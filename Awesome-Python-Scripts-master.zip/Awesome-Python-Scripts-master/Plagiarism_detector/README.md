# Plagiarism Detector
This script helps to detect the amount (percentage) of similarity between 2 files .

## Input
It takes paths of 2 files you want to compare as input

## Output
It returns the percentage of similarity between the 2 files