# Github_Bot
A CLI tool to get github user and repository details.

```
>python main.py -f user -l username
>python main.py -f repo -l username reponame
```

 ![](readme_assets/img.png)
