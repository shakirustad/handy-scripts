This is a simple Python script that will generate text with a neat border made from ASCII pipe characters.
Just run the script and input your lines of text, and it will print out the text with the border.
Enjoy! :D
