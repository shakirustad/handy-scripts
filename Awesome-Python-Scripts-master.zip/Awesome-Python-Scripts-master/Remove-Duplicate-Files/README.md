# Remove Duplicate Files
A python script to find/remove duplicate files from the user specified directory

# Usage
Simply run the script removeDuplicateFiles.py from the terminal after specifying the path
