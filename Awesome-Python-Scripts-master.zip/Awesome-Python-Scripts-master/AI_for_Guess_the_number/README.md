This is a simulation of a computer trying to guess a number, it works with any number of zeroes, furthest i got was 13000 zeroes, so have fun . :)
