# Description: PDF2text
this is a small script to make a extract text from pdf file.  

### Dependencies:
1- [pdftotext](https://pypi.org/project/pdftotext/)

## Usage
Run ```python script.py``` then enter path of pdf file.



