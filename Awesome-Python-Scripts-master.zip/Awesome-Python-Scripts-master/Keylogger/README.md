# Keylogger
A script written in Python that logs your input from the keyboard.


### Steps to run this on terminal

- Clone the project.
- Install the dependencies listed in requirements.txt.
- Run `python keylogger.py` in your terminal. 


### PS

- You can use Delete key to exit the script. 
- You can open log.txt to view your log.


### Author

**[Preet Mishra](https://www.github.com/preetmishra)** 