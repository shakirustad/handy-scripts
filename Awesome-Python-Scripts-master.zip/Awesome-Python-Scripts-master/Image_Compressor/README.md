# Image_Compressor

This script compresses the image choosen to much reduced size. Image can be of any format.
Note : The image should be in same folder as the script
It will return with the compressed image when you compile.
It automates the task of compressing the image in day to day lives.

# Dependencies:

   pip install image

