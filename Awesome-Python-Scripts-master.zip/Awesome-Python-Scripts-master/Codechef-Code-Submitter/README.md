# Automated Submission
A simple script to submit you code on [https://www.codechef.com] using selenium.