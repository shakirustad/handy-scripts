# Python Command Line Translator
Use google translate library to translate text from command line.

## Requirements

Python 3.xx
googletrans
```bash
pip install googletrans

```

### Usage
python Translate.py <text> -s <source_lang> -d <destination_lang>
