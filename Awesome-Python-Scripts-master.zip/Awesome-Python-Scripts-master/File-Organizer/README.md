# File Organizer
Organizes your files in the folder according to their extension by grouping them together.

# Libraries Used
- 

# Usage
Just run the command `python3 file-organizerpy` from your terminal/bash.
