# Port Scanner
A simple tool that asynchronously scans a server's ports with python. It's pretty quick as it processes ports in batches of 256.

## Required libraries
None, the only libraries that are used are built-ins.

## Usage
Use "port_scanner.py", and enter the IP that you want to scan when prompted.
