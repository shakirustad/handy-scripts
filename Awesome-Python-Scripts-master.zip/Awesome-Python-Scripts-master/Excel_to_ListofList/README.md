# Excel to Python List of List Converter
A simple tool which reads an excel file and any corresponding sheet, and converts it to python list of list data structure.

## Libraries Required
1. xlrd
`$pip install xlrd`

## Usage
A sample script `excel_to_list_usage.py` has been provided to show the usage of the ExcelToList. It reads the excel and its sheet, and prints the list of list. 