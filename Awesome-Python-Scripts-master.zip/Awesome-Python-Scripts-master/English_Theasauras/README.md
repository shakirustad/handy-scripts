# English Theasauras
A simple and smart command-line dictionary that displays the definition of the words entered by the user.

## Usage
To start the dictionary type:
```bash
$ python app.py
```
ENJOY 🤩