# Subtitle Downloader
A simple script to download subtitles from [http://thesubdb.com/]

##Dependencies
 It requires `python3` and `request`.
 To install `request`, you need `pip3` or python3.

## Usage
You can directly run the script `subdownloader.py` with the queries supplied from the command line.
If you make the script executable and add it to the system path, then you can directly run the script.
