## Cryptocurrency Prices

This programme gets the live price of cryptocurrencies.

## Requirements

Install the required libraries:

	$ pip install -r requirements.txt

After that run with:

	$ python cryptocurrency-prices.py
