# PY-CLEAN

Tool to organize Directories


### Installations and Dependencies

-> [Python](https://python.org) Installed

### How to execute the file:

1. Windows Users: Open CMD/ Powershell -> Navigate to the Cloned Directory and then Type In:

```python
python main.py
```

2. OSX/ Linux: Open Terminal -> Navigate to the Cloned Directory and then Type In:

```python
python3 main.py
```

### Note

-> Kindly do not modify any file (unless you know what you are doing).
