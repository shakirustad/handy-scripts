## Harry Potter Cloak using OpenCV

This is a fun python script to simulate a harry potter cloak using image masking with the help of opencv library.
It also uses the numpy library for some mathematical calculations.

Requirements: You will need Python installed on your system along with numpy and opencv library for this script to work properly.