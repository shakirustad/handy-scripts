# Python RSA Key Pair Generator
This python script will generate a private and public key pair using the RSA algorithm

## Modules used

Math 
```
import math
```

Random
```
import random
```

#Usage 
You can use the public and private key to encrypt and decrypt information
Run the python file and get key pairs or edit the code and define your custom bounds in the random limits
```
random.randint(start,end)
```
