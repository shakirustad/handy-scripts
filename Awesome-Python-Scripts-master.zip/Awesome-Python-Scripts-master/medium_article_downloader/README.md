A simple python script download latest articles from medium topicwise and save them in text files.

It basically scrapes the site using requests and bs4 modules. I made it just for fun after I read Automate the Boring Stuff with Python by Al Sweigart.