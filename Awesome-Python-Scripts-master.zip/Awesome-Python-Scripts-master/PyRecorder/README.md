# PyRecorder

## Record Preview

![image](https://github.com/jainrocky/screen_recorder/blob/master/record_preview.PNG)

## Stop Preview

![image](https://github.com/jainrocky/screen_recorder/blob/master/stop_preview.PNG)

* [Download](https://github.com/jainrocky/screen_recorder/blob/master/dist/PyRecorder.exe) Executable File
