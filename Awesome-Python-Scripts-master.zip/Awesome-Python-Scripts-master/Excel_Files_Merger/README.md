# Excel Files Merger
A simple script that excel files with similar table structure from a given path as input and creates a unified excel workbook.

## Libraries Required
1. openpyxl
`$pip install openpyxl`

## Usage
A sample script 'Combine excel files into 1.py' has been provided to show the usage of the Excel Merger. When the scipt is run, it will ask for the name of the Unified Workbook and the path of the folder containing the excel files that need to be merged.