## Asymmetric Encryption in python

An example of asymmetric encryption in python using a public/private keypair - utilizes RSA from PyCrypto library 

```bash
pip install pycrypto
python asymmetric.py
```