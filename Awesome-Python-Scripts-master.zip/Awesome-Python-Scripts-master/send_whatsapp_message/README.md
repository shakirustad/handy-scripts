# Send Whatsapp message!

One can easily send a whatsapp message using this script.
**Pre-requisite:** Scan QR code manually.


## Requirements

- Python3
- Selenium
```console
$ pip install -U selenium
```
- Chromedriver (Needs to be in PATH)

## Instructions

- Install selenium of python module in a recognized location on your desktop.
- Install chromedriver from here. [https://chromedriver.chromium.org/downloads]

**NOTE :** The version of Google Chrome and chromedriver has to be same.
