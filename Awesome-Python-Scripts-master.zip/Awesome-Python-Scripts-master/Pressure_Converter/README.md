# Developed and maintained by [Osagie Iyayi](https://github.com/E-wave112)

- This simple program converts between different common units of pressure such as
Pascal(Pa),Bar(bar),Millimeter Mercury(mmHg) and atmosphere(atm).
the test cases are based on the fact that the value of pressure
on it's own can never be negative,except in cases where it is relative to another kind of pressure.

- Run the doctest via the command

```
$ python -m doctest -v Pressure_Converter/pressure_converter_script.py
```