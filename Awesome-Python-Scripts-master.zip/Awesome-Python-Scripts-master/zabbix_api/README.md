# Zabbix-API
This utility allows you to fetch daily alerts from Zabbix Moniotring Tool and send it as mail. It will use Postflix as SMTP or relay server

# Usage

`python dailyAlertMail.py <Zabbix-master-url>`
