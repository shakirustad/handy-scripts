# HTML Table to Python List of List Converter
A simple tool which takes a HTML table as string, and converts it to python list of list data structure and returns the same.

## Libraries Required
1. Beautiful Soap
`$pip install beautifulsoup4`

## Usage
A sample script `html_table_to_list_usage.py` has been provided to show the usage of the HTMLTableToList. It takes a string of html table, and prints the corresponding list of list.
