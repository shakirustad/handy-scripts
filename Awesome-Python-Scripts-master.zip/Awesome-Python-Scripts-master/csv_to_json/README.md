# CSV to JSON Converter
A python script that converts the csv file into json

## CLI interface
![image](https://github.com/hastagAB/Awesome-Python-Scripts/blob/master/csv_to_json/img/CLI.jpg)

## Files
before<br/>
![before](https://github.com/hastagAB/Awesome-Python-Scripts/blob/master/csv_to_json/img/before.jpg)<br/>
After<br/>
![after](https://github.com/hastagAB/Awesome-Python-Scripts/blob/master/csv_to_json/img/after.jpg)
