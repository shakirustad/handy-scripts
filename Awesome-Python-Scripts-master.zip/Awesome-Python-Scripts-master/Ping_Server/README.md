# Ping_server
/P>this is a pyhton script to ping your servers automatically and alert you with telegram messages or telephone call when you server are down or you can manipulate this logig based on diffrent http return status </p><br/>
<p>you need to liitle configeration in telegram and twillio make it work</p> 
